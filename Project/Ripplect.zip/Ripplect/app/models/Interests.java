package models;

import java.util.*;

public class Interests {

    public static List<String> list() {
        List<String> all = new ArrayList<String>();
        
        all.add("Film");
        all.add("Music");
       
        all.add("Photography");
        all.add("Technology");
        all.add("Travel");
        all.add("Cooking");
        all.add("Sports");
        all.add("Painting");
        all.add("Dance");
        return all;
    }

}