package models;

import java.util.*;


public class OpinionObj{

  public Long id;

  public OpinionDetails opiniondetails;

  public String vote;

  public int countAgree;

  public int countDisagree;

}